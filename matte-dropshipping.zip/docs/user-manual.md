# User Manual - MatteLatino Dropshipping Website

## Introduction

Welcome to MatteLatino, your complete dropshipping solution for matte products with a Latino-inspired design. This user manual will guide you through all the features and functionality of your new website.

## For Customers

### Account Management

#### Creating an Account
1. Click on the user icon in the top navigation bar
2. Select the "Crear Cuenta" (Create Account) tab
3. Fill in your personal information
4. Accept the terms and conditions
5. Click "Crear Cuenta"

#### Logging In
1. Click on the user icon in the top navigation bar
2. Enter your email and password
3. Click "Iniciar Sesión" (Login)

#### Managing Your Profile
1. Log in to your account
2. Access your account page
3. View your personal information and order history
4. Click "Editar Información" to update your details

### Shopping

#### Browsing Products
1. Navigate through categories using the main menu
2. Use filters to narrow down products by price, color, etc.
3. Toggle between grid and list views for different browsing experiences
4. Click on any product to view details

#### Product Details
1. View high-resolution images of the product
2. Read detailed descriptions and specifications
3. Select color options when available
4. Choose quantity
5. Read customer reviews

#### Shopping Cart
1. Add products to your cart by clicking "Añadir al Carrito"
2. View your cart by clicking the cart icon in the navigation bar
3. Adjust quantities or remove items as needed
4. Apply discount codes if available
5. Proceed to checkout

#### Wishlist
1. Add products to your wishlist by clicking the heart icon
2. Access your wishlist by clicking the heart icon in the navigation bar
3. Move items from wishlist to cart when ready to purchase
4. Remove items from your wishlist as needed

#### Checkout Process
1. Review your cart items
2. Enter shipping information
3. Select shipping method
4. Enter payment details
5. Review and confirm your order
6. Receive order confirmation email

### Customer Support

#### Contacting Support
1. Click on "Contacto" in the main navigation
2. Fill out the contact form with your inquiry
3. Submit the form
4. Expect a response within 24 hours

#### Tracking Orders
1. Log in to your account
2. Go to "Mi Cuenta" (My Account)
3. View your order history
4. Click on any order to see detailed status and tracking information

## For Store Owners

### Admin Dashboard

#### Accessing the Dashboard
1. Navigate to yourdomain.com/admin
2. Log in with your admin credentials
3. View the main dashboard with sales statistics and recent orders

#### Managing Products

##### Adding Products
1. Go to the Products section in the admin dashboard
2. Click "Añadir Producto" (Add Product)
3. Fill in all product details:
   - Name
   - Description
   - Price
   - Category
   - Images
   - Inventory status
4. Click "Guardar Producto" (Save Product)

##### Editing Products
1. Find the product in the product list
2. Click the edit icon
3. Update the product information
4. Click "Actualizar Producto" (Update Product)

##### Deleting Products
1. Find the product in the product list
2. Click the delete icon
3. Confirm deletion

##### Managing Categories
1. Access the Categories section
2. Add, edit, or delete categories as needed
3. Organize products by assigning them to appropriate categories

#### Order Management

##### Viewing Orders
1. Go to the Orders section in the admin dashboard
2. View all orders with their status
3. Click on any order to see details

##### Processing Orders
1. Open the order details
2. Update the order status as you process it
3. Add tracking information when shipping
4. Send notifications to customers about order status changes

#### Customer Management

##### Viewing Customer Information
1. Go to the Customers section
2. View the list of all registered customers
3. Click on any customer to see their details and order history

##### Messaging Customers
1. Select a customer from the list
2. Use the messaging interface to send them a direct message
3. View message history with each customer

##### Managing Reviews
1. Go to the Reviews section
2. Approve or reject customer reviews
3. Respond to reviews when appropriate

#### Email Marketing

##### Creating Email Templates
1. Go to the Email Templates section
2. Create new templates or edit existing ones
3. Use variables to personalize emails

##### Sending Campaigns
1. Select an email template
2. Choose recipient list
3. Schedule or send immediately
4. Track open and click rates

### Website Customization

#### Updating Content
1. Go to the Content section in the admin dashboard
2. Edit homepage banners, about page, and other static content
3. Save changes to update the website

#### Design Customization
1. Access the Design settings
2. Modify color schemes, fonts, and layout options
3. Preview changes before publishing
4. Apply changes to make them live

## Technical Support

If you encounter any technical issues or have questions about using your MatteLatino website, please contact our support team:

- Email: support@mattelatino.com
- Support Hours: Monday-Friday, 9am-5pm EST

We're here to help you make the most of your dropshipping business!
